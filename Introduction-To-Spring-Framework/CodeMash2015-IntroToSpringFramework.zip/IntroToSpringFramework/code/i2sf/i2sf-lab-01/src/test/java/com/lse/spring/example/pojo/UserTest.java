package com.lse.spring.example.pojo;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


/**
 * Unit test for simple User.
 */
public class UserTest {
	private User user;
	
	
	@Before
	public void setup() {
		user = new User();
	}
	
	@After
	public void teardown() {		
	}
	
	@Test
	public void testCheckingAccount() {
			Double takeOut = 20.0;
			Double initialDeposit = 100.0;
			Double initialBalance = user.getCheckingBalance();
			Assert.assertTrue(initialBalance>=0.0);

			Double balance = user.depositToChecking(initialDeposit);
			System.out.println("starting balance: "+balance);

			Assert.assertEquals("initial balance", Double.valueOf(initialBalance+initialDeposit),balance);
			
			System.out.println("  withdrawing $"+takeOut+" dollars");
			balance = user.withdrawFromChecking(takeOut);
			System.out.println("ending balance: "+balance);		

			Assert.assertEquals("new balance", Double.valueOf(initialBalance+initialDeposit-takeOut), balance);
			
			System.out.println("object tree: "+user);
			
			Assert.assertEquals("AcmeBank", user.getAtm().getBank().getBankName());
	}	
}
