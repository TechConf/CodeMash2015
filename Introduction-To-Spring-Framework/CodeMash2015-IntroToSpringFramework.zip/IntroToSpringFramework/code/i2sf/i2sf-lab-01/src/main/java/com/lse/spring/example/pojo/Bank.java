package com.lse.spring.example.pojo;

public interface Bank {
	String getBankName();
	double getCheckingBalance();
	double creditChecking(double amount);
	double debitChecking(double amount);
}
