package com.lse.spring.example.pojo;

/**
 * @author   ddlucas
 */
public class AcmeATM implements ATM {
	private String type = "AcmeATM";

	private Bank bank;
	
	public AcmeATM() {
		System.out.println("creating DieboldATM...");		
		bank = new AcmeBank();
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getCheckingBalance() {
		return bank.getCheckingBalance();
	}

	public double depositToChecking(double amount) {
		return bank.creditChecking(amount);
	}

	public double withdrawFromChecking(double amount) {
		return bank.debitChecking(amount);
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("{ class: ");
		sb.append(this.getClass().getCanonicalName());
		sb.append(",\n\ttype: ").append(type);
		sb.append(",\n\tbank: ").append(bank);
		sb.append(" }\n");		
		return sb.toString();
	}
	
}
