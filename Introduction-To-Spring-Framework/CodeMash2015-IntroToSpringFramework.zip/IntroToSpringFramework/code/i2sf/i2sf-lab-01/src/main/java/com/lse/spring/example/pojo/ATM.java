package com.lse.spring.example.pojo;

public interface ATM {
	String getType();
	Bank getBank(); 
	double getCheckingBalance();
	double depositToChecking(double amount);
	double withdrawFromChecking(double amount);
}
