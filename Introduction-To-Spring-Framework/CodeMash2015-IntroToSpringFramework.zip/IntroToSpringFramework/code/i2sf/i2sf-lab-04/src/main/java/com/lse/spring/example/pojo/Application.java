package com.lse.spring.example.pojo;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Application {
    
    public static void main(String[] args) {
    	System.getProperties().setProperty("spring.profiles.active", 
    			"acme-bank");
//    			"other-bank");
    	
    	ClassPathXmlApplicationContext appCtx = new ClassPathXmlApplicationContext(
    		        new String[] {"spring-application.xml"});
    	try {
			User user = (User) appCtx.getBean("user");
			
			double initialBalance = user.getCheckingBalance();
			System.out.println("user="+user);
			System.out.println("current balance = $ "+initialBalance);

    	}
    	finally {
    		appCtx.close();
    	}
	}

}
