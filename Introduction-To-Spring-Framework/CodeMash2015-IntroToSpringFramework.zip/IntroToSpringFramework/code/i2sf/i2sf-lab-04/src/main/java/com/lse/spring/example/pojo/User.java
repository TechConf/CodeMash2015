package com.lse.spring.example.pojo;

/**
 * @author   ddlucas
 */
public class User {

	private ATM atm;
	
	public ATM getAtm() {
		return atm;
	}

	public void setAtm(ATM atm) {
		this.atm = atm;
	}

	public User() {
		System.out.println("creating User...");
//		atm = new AcmeATM();
	}
	
	public double withdrawFromChecking(double amount) {
		return atm.withdrawFromChecking(amount);
	}
	
	public double depositToChecking(double amount) {
		return atm.depositToChecking(amount);
	}
	
	public double getCheckingBalance() {
		return atm.getCheckingBalance();
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("{ class: ");
		sb.append(this.getClass().getCanonicalName());
		sb.append(",\n\tatm: ").append(atm);
		sb.append(" }\n");		
		return sb.toString();
	}
}
