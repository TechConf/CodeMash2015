package com.lse.spring.example.pojo;

/**
 * @author ddlucas
 */
public class OtherBank implements Bank {
	private String bankName = "OtherBank";
	private double checkingBalance;

	public OtherBank() {
		System.out.println("creating OtherBank...");
	}

	public double creditChecking(double amount) {
		System.out.println("bank checking balance: " + checkingBalance);
		System.out.println("adding amount=" + amount);
		checkingBalance += amount;
		System.out.println("bank checking balance: " + checkingBalance);
		return checkingBalance;
	}

	public double debitChecking(double amount) {
		System.out.println("bank checking balance: " + checkingBalance);
		System.out.println("subtracting amount=" + amount);
		checkingBalance -= amount;
		System.out.println("bank checking balance: " + checkingBalance);
		return checkingBalance;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public double getCheckingBalance() {
		return checkingBalance;
	}

	public void setCheckingBalance(double checkingBalance) {
		this.checkingBalance = checkingBalance;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("{ class: ");
		sb.append(this.getClass().getCanonicalName());
		sb.append(",\n\tbankName: ").append(bankName);
		sb.append(",\n\tcheckingBalance: ").append(checkingBalance);
		sb.append(" }\n");
		return sb.toString();
	}

}
