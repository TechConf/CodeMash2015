-- drop tables 
drop table ACCOUNT;
drop table AUDIT;

