-- load Account table
insert into ACCOUNT(acct_number,balance,acct_type) values ('1234567890',100.0, 'Checking');
insert into ACCOUNT(acct_number,balance,acct_type) values ('2341567891',1000.0, 'Savings');
insert into ACCOUNT(acct_number,balance,acct_type) values ('3412567892',10000.0, 'Money Market');
insert into ACCOUNT(acct_number,balance,acct_type) values ('4321567893',100000.0, '401K');

select acct_number, balance, acct_type 
		from account 
		where acct_number IN ('1234567890','2341567891')
;
