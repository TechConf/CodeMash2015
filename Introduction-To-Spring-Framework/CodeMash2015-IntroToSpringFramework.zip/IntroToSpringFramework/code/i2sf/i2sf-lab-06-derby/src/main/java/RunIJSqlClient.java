
/*
 * Simple class to start sql client
 */
public class RunIJSqlClient {
	public static void main(String[] args) {
		try {
			setupExitHook();
			org.apache.derby.tools.ij.main(args);
			
		} catch (Throwable e) {
			e.printStackTrace();
		}
		finally {
			System.out.println("RunIJSqlClient exiting !");
		}
	
	}
	
	public static void setupExitHook() {
		final Thread mainThread = Thread.currentThread();
		Runtime.getRuntime().addShutdownHook(new Thread() {
		    public void run() {
				try {
					mainThread.join();
				} catch (Throwable t) {
//					t.printStackTrace();
				}
		    }
		});
	}
}
