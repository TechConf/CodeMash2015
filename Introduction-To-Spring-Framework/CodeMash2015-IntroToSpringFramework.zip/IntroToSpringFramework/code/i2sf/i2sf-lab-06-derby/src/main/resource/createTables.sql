-- create Account table
create table ACCOUNT( acct_number VARCHAR(10) PRIMARY KEY,
		      balance DECIMAL(12,2) DEFAULT 0,
		      acct_type VARCHAR(32) NOT NULL
);

create table AUDIT( event_id VARCHAR(38) PRIMARY KEY,
		      event_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		      event_message VARCHAR(2000) NOT NULL
);
