import java.io.PrintWriter;
import java.sql.DriverManager;

import org.apache.derby.drda.NetworkServerControl;

/*
 * Simple class to start derby
 */
public class RunDerby {
	static NetworkServerControl derbyControl;
    
	public static void main(String[] args) {
		try {
			setupExitHook();

			System.setProperty("derby.system.home","derby-data");
			System.setProperty("derby.drda.host","localhost");
			System.setProperty("derby.drda.portNumber","1527");
			System.setProperty("derby.drda.maxThreads","10");
//			System.setProperty("derby.drda.logConnections","true");
			
			derbyControl = new NetworkServerControl();
			derbyControl.start(new PrintWriter(System.out));
			Thread.sleep(5000L);			
			
			while (running()) {
				Thread.sleep(10000L);
			}
		} catch (Throwable e) {
			e.printStackTrace();
		}
		finally {
			System.out.println("RunDerby exiting !");
		}
	
	}
	
	public static void setupExitHook() {
		final Thread mainThread = Thread.currentThread();
		Runtime.getRuntime().addShutdownHook(new Thread() {
		    public void run() {
				try {
					DriverManager.getConnection("jdbc:derby:;shutdown=true");
					mainThread.join();
				} catch (Throwable t) {
//					t.printStackTrace();
				}
		    }
		});
	}

	public static boolean running() {
		boolean alive = true;
		if (derbyControl!=null) {
			try {
				derbyControl.ping();
			} catch (Throwable t) {
				t.printStackTrace();
				alive = false;
			}
		}
		return alive ;
	}
}
