package com.lse.spring.example.beans;

import org.joda.time.DateTime;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.lse.spring.example.data.config.AppConfig;
import com.lse.spring.example.data.domain.AuditInfo;
import com.lse.spring.example.data.persistence.AuditDAO;


/**
 * Unit test for simple User.
 */

/**
 * Unit test for simple User.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("acme-bank")
@ContextConfiguration(classes=AppConfig.class)
@TransactionConfiguration(defaultRollback=false)

public class AuditInfoDAOJDBCTest {

	@Autowired
	private AuditDAO dao ;
	
	AuditInfo event1 = new AuditInfo("AABB", new DateTime(), "Checking withdraw of $100.00");
	AuditInfo event2 = new AuditInfo("AACC", new DateTime(), "Savings deposit of $2000.00");

	@Before
	public void setUp() throws Exception {
		dao.remove(event1);
		dao.remove(event2);
		dao.save(event1);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFetchAuditInfo() {
		AuditInfo found = dao.fetchAuditInfo(event1.getEventId());
		Assert.assertEquals("found",event1, found);
	}

	@Test
	public void testSave() {
		AuditInfo found = dao.fetchAuditInfo(event2.getEventId());
		Assert.assertNull("not found",found);

		AuditInfo result = dao.save(event2);
		Assert.assertNotNull("saved",result);		
		Assert.assertEquals("found",event2, result);
	
		found = dao.fetchAuditInfo(event2.getEventId());
		Assert.assertNotNull("found",found);		
		Assert.assertEquals("found",found, result);
	}

	@Test
	public void testRemove() {
		AuditInfo removed = dao.remove(event1);
		Assert.assertEquals("removed",event1, removed);
		AuditInfo found = dao.fetchAuditInfo(event1.getEventId());
		Assert.assertNull("removed",found);
		
	}

	@Test
	public void testCountAllAccounts() {
		int actual = dao.countAllAuditInfos();
		Assert.assertTrue("count", actual>=2);		
	}
	
}
