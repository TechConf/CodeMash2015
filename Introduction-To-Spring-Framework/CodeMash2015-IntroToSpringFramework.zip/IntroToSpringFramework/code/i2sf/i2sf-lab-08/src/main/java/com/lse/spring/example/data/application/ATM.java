package com.lse.spring.example.data.application;

import com.lse.spring.example.data.service.Bank;

public interface ATM {
	String getType();
	Bank getBank(); 
	double getAccountBalance(String accountNumber);
	double depositToAccount(String accountNumber, double amount);
	double withdrawFromAccount(String accountNumber, double amount);
	void transfer(String sourceAccountNumber,
			String destinationAccountNumber, double amount);	
}	
