package com.lse.spring.example.data.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lse.spring.example.data.domain.AuditInfo;

@Repository
public class AuditDAOJDBC implements AuditDAO {
	private static final String SQL_DELETE_ACCOUNT = "delete from AUDIT where event_id=:eventId";

	private static final String SQL_COUNT_ALL = "SELECT COUNT(1) FROM ACCOUNT";

	private static final String SQL_INSERT_ACCOUNT = "insert into AUDIT(event_id, event_time, event_message) values (:eventId,:eventTime,:eventMessage)";

	private static final String SQL_FETCH_ACCOUNT = "select event_id, event_time, event_message from AUDIT where event_id=:eventId";

	@Autowired
	private DataSource dataSource;
	
	private NamedParameterJdbcTemplate jdbc;


	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbc = new NamedParameterJdbcTemplate(dataSource);
	}

	public AuditDAOJDBC() {
	}
	
	@PostConstruct
	public void postConstruct() {
		if (jdbc==null) {
			jdbc = new NamedParameterJdbcTemplate(dataSource);
		}
	}
	
	private static class AuditInfoMapper implements RowMapper<AuditInfo> {
		public AuditInfo mapRow(ResultSet rs, int row) throws SQLException {
			AuditInfo obj = new AuditInfo();
			obj.setEventId(rs.getString("event_id"));
			Timestamp ts = rs.getTimestamp("event_time");
			if (ts!=null) {
				DateTime dt = new DateTime(ts.getTime());
				obj.setEventTime(dt);				
			}
			else {
				obj.setEventTime(null);
			}
			obj.setEventMessage(rs.getString("event_message"));
			return obj;
		}
	};
	
	private AuditInfoMapper mapper = new AuditInfoMapper();
	
	@Transactional(readOnly=true)
	public AuditInfo fetchAuditInfo(String eventId) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("eventId",eventId);
		AuditInfo result = null; 
		List<AuditInfo> list = jdbc.query(SQL_FETCH_ACCOUNT,map, mapper);
		if (list!=null && list.size()>0) {
			result = list.get(0);
		}
		return result;
	}
	
	@Transactional(readOnly=true)
	public int countAllAuditInfos() {
		Map<String,Object> map = new HashMap<String,Object>();
		Integer count = jdbc.queryForObject(SQL_COUNT_ALL, map, Integer.class);
		if (count==null) {
			count = 0;
		}
		return count;
	}

	@Transactional
	public AuditInfo save(AuditInfo event) {
		if (event.getEventId()==null) {
			event.setEventId(UUID.randomUUID().toString());
		}
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("eventId",event.getEventId());
		DateTime dt = event.getEventTime();
		if (dt==null) {
			dt = new DateTime();			
		}
		map.put("eventTime", new Timestamp(dt.toDate().getTime()));
		map.put("eventMessage",event.getEventMessage());

		//do we update or insert?
		AuditInfo found = fetchAuditInfo(event.getEventId());
		if (found!=null) {
//			jdbc.update(SQL_UPDATE_ACCOUNT, map);
		}
		else {
			jdbc.update(SQL_INSERT_ACCOUNT, map);
		}
		//what if the insert or update triggered a data change, get the latest and return it
		found = fetchAuditInfo(event.getEventId());
		return found;
	}
	
	@Transactional
	public AuditInfo remove(String eventId) {
		AuditInfo found = fetchAuditInfo(eventId);
		if (found!=null) {
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("eventId",eventId);			
			jdbc.update(SQL_DELETE_ACCOUNT, map);
		}
		return found;
	}

	@Transactional
	public AuditInfo remove(AuditInfo event) {
		return remove(event.getEventId());
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("{ class: ");
		sb.append(this.getClass().getCanonicalName());
		sb.append(",\n\t size: ").append(countAllAuditInfos());
		sb.append(" }\n");		
		return sb.toString();
	}

}