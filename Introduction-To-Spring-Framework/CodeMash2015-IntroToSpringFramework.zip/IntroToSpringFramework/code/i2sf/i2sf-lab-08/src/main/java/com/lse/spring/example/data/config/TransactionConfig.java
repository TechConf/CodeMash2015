package com.lse.spring.example.data.config;

import java.util.Properties;
import java.util.UUID;

import javax.sql.DataSource;
import javax.transaction.TransactionManager;
import javax.transaction.UserTransaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.jta.JtaTransactionManager;

import com.atomikos.icatch.jta.UserTransactionImp;
import com.atomikos.icatch.jta.UserTransactionManager;
import com.atomikos.jdbc.AtomikosDataSourceBean;

@EnableTransactionManagement
@Configuration
@ComponentScan(value = "com.lse.spring.example")
public class TransactionConfig {
	private static final int DEFAULT_TX_TIMEOUT = 15 * 60 * 1000;  //15 minutes
	
	@Autowired 
	private Environment environment ;

	@Value("${jdbc.driverClassName}")
	private String driverClassName;
	@Value("${jdbc.url}")
	private String url;
	@Value("${jdbc.username}")
	private String username;
	@Value("${jdbc.password}")
	private String password;
	@Value("${jdbc.databaseName}")
	private String databaseName;
	@Value("${jdbc.serverName}")
	private String serverName;
	@Value("${jdbc.port}")
	private String portNumber;

	@Bean(initMethod = "init", destroyMethod = "close")
	public DataSource getDataSource() {
		AtomikosDataSourceBean ds = new AtomikosDataSourceBean();
		ds.setUniqueResourceName("ds-01-"+UUID.randomUUID().toString());
		ds.setXaDataSourceClassName(driverClassName);
		ds.setXaProperties(dataSourceXAProperties());
		ds.setPoolSize(10);
		ds.setMinPoolSize(0);
		ds.setMaxIdleTime(10);
		ds.setBorrowConnectionTimeout(1);
		ds.setPoolSize(2);
		return ds;
	}

	private Properties dataSourceXAProperties() {
		Properties props = new Properties();
		props.setProperty("user", username);
		props.setProperty("password", password);
		props.setProperty("databaseName", databaseName);
		props.setProperty("serverName", serverName);
		props.setProperty("portNumber", portNumber);

		return props;
	}

	@Bean
	public UserTransaction userTransaction() throws Throwable {
		UserTransactionImp userTransactionImp = new UserTransactionImp();
		userTransactionImp.setTransactionTimeout(DEFAULT_TX_TIMEOUT);
		return userTransactionImp;
	}

	@Bean(initMethod = "init", destroyMethod = "close")
	public TransactionManager transactionManager() throws Throwable {
		UserTransactionManager userTransactionManager = new UserTransactionManager();
		userTransactionManager.setForceShutdown(false);
		return userTransactionManager;
	}
	
	@Bean
	public PlatformTransactionManager platformTransactionManager()  throws Throwable {
		return new JtaTransactionManager( 
                         this.userTransaction(), this.transactionManager());
	}
} 