package com.lse.spring.example.data.domain;

import java.util.UUID;

import org.joda.time.DateTime;

public class AuditInfo {
	private String eventId;
	private DateTime eventTime;
	private String eventMessage;
	
	public AuditInfo() {}
	
	public AuditInfo(String message) {
		this(new DateTime(), message);
	}

	public AuditInfo(DateTime eventTime, String eventMessage) {
		this(UUID.randomUUID().toString(), eventTime, eventMessage);
	}
	
	public AuditInfo(String eventId, DateTime eventTime, String eventMessage) {
		this.eventId = eventId;
		this.eventTime = eventTime;
		this.eventMessage = eventMessage;
	}

	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public DateTime getEventTime() {
		return eventTime;
	}
	public void setEventTime(DateTime eventTime) {
		this.eventTime = eventTime;
	}
	public String getEventMessage() {
		return eventMessage;
	}
	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((eventId == null) ? 0 : eventId.hashCode());
		result = prime * result
				+ ((eventMessage == null) ? 0 : eventMessage.hashCode());
		result = prime * result
				+ ((eventTime == null) ? 0 : eventTime.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AuditInfo other = (AuditInfo) obj;
		if (eventId == null) {
			if (other.eventId != null)
				return false;
		} else if (!eventId.equals(other.eventId))
			return false;
		if (eventMessage == null) {
			if (other.eventMessage != null)
				return false;
		} else if (!eventMessage.equals(other.eventMessage))
			return false;
		if (eventTime == null) {
			if (other.eventTime != null)
				return false;
		} else if (!eventTime.equals(other.eventTime))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "AuditInfo [eventId=" + eventId + ", eventTime=" + eventTime
				+ ", eventMessage=" + eventMessage + "]";
	}
	
	
}
