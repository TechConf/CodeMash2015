package com.lse.spring.example.data.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lse.spring.example.data.domain.Account;
import com.lse.spring.example.data.domain.AuditInfo;
import com.lse.spring.example.data.persistence.AccountDAO;
import com.lse.spring.example.data.persistence.AuditDAO;
import com.lse.spring.example.data.persistence.MissingAccountException;

/**
 * @author ddlucas
 */
@Profile("acme-bank")
@Service("theBank")
public class AcmeBank implements Bank {
	@Value("${my.bank.name}")
	private String bankName = "AcmeBank";	

	@Value("${my.bank.balance}")
	private double checkingBalance;

	@Autowired
	private AccountDAO accountDao;
	
	@Autowired
	private AuditDAO auditDao;
	
	public AcmeBank() {
		System.out.println("creating AcmeBank...");
	}
	
	@Transactional
	public double creditAccount(String accountNumber, double amount) {
		Account account = fetchAccount(accountNumber);
		System.out.println("bank checking balance: "+account.getBalance()+" for accountNumber="+accountNumber);
		System.out.println("adding amount="+amount);

		auditDao.save(new AuditInfo("For acct="+accountNumber+", attempting to credit amount="+amount));
		
		account.credit(amount);
		account = accountDao.save(account);
		System.out.println("bank checking balance: "+account.getBalance()+" for accountNumber="+accountNumber);
		return account.getBalance();
	}

	@Transactional
	public double debitAccount(String accountNumber, double amount) {
		Account account = fetchAccount(accountNumber);
		System.out.println("bank checking balance: "+account.getBalance()+" for accountNumber="+accountNumber);
		System.out.println("subtracting amount="+amount);
		
		auditDao.save(new AuditInfo("For acct="+accountNumber+", attempting to debit amount="+amount));

		account.debit(amount);
		account = accountDao.save(account);
		System.out.println("bank checking balance: "+account.getBalance()+" for accountNumber="+accountNumber);
		return account.getBalance();
	}

	private Account fetchAccount(String accountNumber) {
		System.out.println("looking up accountNumber="+accountNumber);
		Account account = accountDao.fetchAccount(accountNumber);
		if (account==null) {
			throw new MissingAccountException("account "+account+" not found");
		}
		return account;
	}
	
	public AccountDAO getAccountDao() {
		return accountDao;
	}

	public void setAccountDao(AccountDAO accountDao) {
		this.accountDao = accountDao;
	}

	public String getBankName() {
		return bankName;
	}
	
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public double getAccountBalance(String accountNumber) {
		Account account = fetchAccount(accountNumber);
		return account.getBalance();
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("{ class: ");
		sb.append(this.getClass().getCanonicalName());
		sb.append(",\n\t bankName: ").append(bankName);
		sb.append(",\n\t accountDao: ").append(accountDao);
		sb.append(" }\n");		
		return sb.toString();
	}

	public double getCheckingBalance() {
		return checkingBalance;
	}

	public void setCheckingBalance(double checkingBalance) {
		this.checkingBalance = checkingBalance;
	}

	public AuditDAO getAuditDao() {
		return auditDao;
	}

	public void setAuditDao(AuditDAO auditDao) {
		this.auditDao = auditDao;
	}

	@Transactional
	public void transfer(String sourceAccountNumber,
			String destinationAccountNumber, double amount) {
		String msg = String.format("transfer request from srcAcct=%s to destAcct=%s for amount=%s",
				sourceAccountNumber, destinationAccountNumber, amount);
		System.out.println(msg);
		auditDao.save(new AuditInfo(msg));
		
		//deposit
		creditAccount(destinationAccountNumber, amount);

		
//		if (true) {
//			throw new MissingAccountException("ERROR, BAD WHAT IF JUST HAPPENED, NOW WHAT ???");
//		}
		
		
		//withdraw
		debitAccount(sourceAccountNumber, amount);
	}

}
