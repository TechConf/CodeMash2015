package com.lse.spring.example.data.service;

public interface Bank {
	String getBankName();
	double getAccountBalance(String accountNumber);
	double creditAccount(String accountNumber, double amount);
	double debitAccount(String accountNumber, double amount);
	void transfer(String sourceAccountNumber, String destinationAccountNumber, double amount );
}
