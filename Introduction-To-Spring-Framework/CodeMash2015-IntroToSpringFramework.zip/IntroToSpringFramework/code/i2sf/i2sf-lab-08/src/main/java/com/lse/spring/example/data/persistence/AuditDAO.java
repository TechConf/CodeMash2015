package com.lse.spring.example.data.persistence;

import com.lse.spring.example.data.domain.AuditInfo;

public interface AuditDAO {
	AuditInfo fetchAuditInfo(String eventId);
	AuditInfo save(AuditInfo event);
	AuditInfo remove(AuditInfo event);
	int countAllAuditInfos();
}
