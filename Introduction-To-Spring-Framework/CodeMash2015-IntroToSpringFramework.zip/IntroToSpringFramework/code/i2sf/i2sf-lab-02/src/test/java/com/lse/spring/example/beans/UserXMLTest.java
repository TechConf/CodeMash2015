package com.lse.spring.example.beans;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lse.spring.example.pojo.User;


/**
 * Unit test for simple User.
 */
public class UserXMLTest {
	
	private ClassPathXmlApplicationContext appCtx;
	
	@Before
	public void setup() {
		appCtx = new ClassPathXmlApplicationContext(
		        new String[] {"spring-application.xml"});
	}
	
	@After
	public void teardown() {		
		appCtx.close();
	}
	
	@Test
	public void testCheckingAccount() {
			
			User user = (User) appCtx.getBean("user");
			
			double takeOut = 20.0;
			double initialDeposit = 100.0;
			Double initialBalance = user.getCheckingBalance();
			Assert.assertTrue(initialBalance>=0.0);

			Double balance = user.depositToChecking(initialDeposit);
			System.out.println("starting balance: "+balance);

			Double expected = initialBalance + initialDeposit;
			Assert.assertEquals("initial balance", expected,balance);
			
			System.out.println("  withdrawing $"+takeOut+" dollars");
			balance = user.withdrawFromChecking(takeOut);
			System.out.println("ending balance: "+balance);		

			Assert.assertEquals("new balance", Double.valueOf(expected-takeOut),balance);
			
			System.out.println("object tree: "+user);
			
			Assert.assertEquals("Acme First Bank", user.getAtm().getBank().getBankName());			
	}	
}
