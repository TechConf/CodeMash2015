package com.lse.spring.example.pojo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * @author ddlucas
 */
@Service("theBank")
public class AcmeBank implements Bank {
	@Value("${my.bank.name}")
	private String bankName = "AcmeBank";	

	@Value("${my.bank.balance}")
	private double checkingBalance;

	public AcmeBank() {
		System.out.println("creating AcmeBank...");
	}

	public double creditChecking(double amount) {
		System.out.println("bank checking balance: " + checkingBalance);
		System.out.println("adding amount=" + amount);
		checkingBalance += amount;
		System.out.println("bank checking balance: " + checkingBalance);
		return checkingBalance;
	}

	public double debitChecking(double amount) {
		System.out.println("bank checking balance: " + checkingBalance);
		System.out.println("subtracting amount=" + amount);
		checkingBalance -= amount;
		System.out.println("bank checking balance: " + checkingBalance);
		return checkingBalance;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public double getCheckingBalance() {
		return checkingBalance;
	}

	public void setCheckingBalance(double checkingBalance) {
		this.checkingBalance = checkingBalance;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("{ class: ");
		sb.append(this.getClass().getCanonicalName());
		sb.append(",\n\tbankName: ").append(bankName);
		sb.append(",\n\tcheckingBalance: ").append(checkingBalance);
		sb.append(" }\n");
		return sb.toString();
	}

}
