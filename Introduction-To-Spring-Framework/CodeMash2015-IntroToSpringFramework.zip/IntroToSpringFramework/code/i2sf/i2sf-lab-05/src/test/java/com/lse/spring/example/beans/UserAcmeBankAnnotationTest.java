package com.lse.spring.example.beans;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.lse.spring.example.pojo.AppConfig;
import com.lse.spring.example.pojo.User;


/**
 * Unit test for simple User.
 */

/**
 * Unit test for simple User.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("acme-bank")
@ContextConfiguration(classes=AppConfig.class)
@TransactionConfiguration(defaultRollback=false)
public class UserAcmeBankAnnotationTest {

	@Autowired(required=true)
	private User user;

	@Before
	public void setup() {
	}
	
	@After
	public void teardown() {		
	}
	
	@Test
	public void testCheckingAccount() {
			
			double takeOut = 20.0;
			double initialDeposit = 100.0;

			Double initialBalance = user.getCheckingBalance();
			Assert.assertTrue(initialBalance>=0.0);

			Double balance = user.depositToChecking(initialDeposit);
			System.out.println("starting balance: "+balance);

			Double expected = initialBalance + initialDeposit;
			Assert.assertEquals("initial balance", expected,balance);
			
			System.out.println("  withdrawing $"+takeOut+" dollars");
			balance = user.withdrawFromChecking(takeOut);
			System.out.println("ending balance: "+balance);		

			Assert.assertEquals("new balance", Double.valueOf(expected-takeOut),balance);
			
			System.out.println("object tree: "+user);
			
			Assert.assertEquals("Acme First Bank", user.getAtm().getBank().getBankName());			
	}	
}
