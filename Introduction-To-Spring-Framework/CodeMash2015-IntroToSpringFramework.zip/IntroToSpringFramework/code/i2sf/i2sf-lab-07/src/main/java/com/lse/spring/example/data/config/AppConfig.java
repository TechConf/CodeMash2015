package com.lse.spring.example.data.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@ComponentScan(basePackages = "com.lse.spring.example")
@PropertySource("classpath:${APP_ENV:application}.properties")
public class AppConfig {
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}
	
	@Value("${jdbc.driverClassName}")     private String driverClassName;
	@Value("${jdbc.url}")                 private String url;
	@Value("${jdbc.username}")             private String username;
	@Value("${jdbc.password}")             private String password;

	@Bean   
	public DataSource getDataSource()
	{
		DriverManagerDataSource ds = new DriverManagerDataSource();       
		ds.setDriverClassName(driverClassName);
		ds.setUrl(url);
		ds.setUsername(username);
		ds.setPassword(password);       
		return ds;
	}

//    <bean id="dataSource" class="org.apache.commons.dbcp.BasicDataSource" destroy-method="close">
//        <property name="driverClassName" value="${jdbc.driverClassName}"/>
//        <property name="url" value="${jdbc.url}"/>
//        <property name="username" value="${jdbc.username}"/>
//        <property name="password" value="${jdbc.password}"/>
//    </bean>


}
