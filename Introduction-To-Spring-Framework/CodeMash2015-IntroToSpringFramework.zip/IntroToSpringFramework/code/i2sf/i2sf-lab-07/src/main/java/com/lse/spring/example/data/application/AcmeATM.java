package com.lse.spring.example.data.application;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.lse.spring.example.data.service.Bank;

/**
 * @author   ddlucas
 */
@Service("theAtm")
public class AcmeATM implements ATM {
	@Value("${my.atm.type}") 
	private String type = "AcmeATM";
	
	@Autowired
	@Qualifier("theBank")
	private Bank bank;
	
	public AcmeATM() {
		System.out.println("creating AcmeATM...");		
//		bank = new AcmeBank();
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getAccountBalance(String accountNumber) {
		return bank.getAccountBalance(accountNumber);
	}

	public double depositToAccount(String accountNumber, double amount) {
		return bank.creditAccount(accountNumber,amount);
	}

	public double withdrawFromAccount(String accountNumber, double amount) {
		return bank.debitAccount(accountNumber, amount);
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("{ class: ");
		sb.append(this.getClass().getCanonicalName());
		sb.append(",\n\t type: ").append(type);
		sb.append(",\n\t bank: ").append(bank);
		sb.append(" }\n");
		return sb.toString();
	}

}
