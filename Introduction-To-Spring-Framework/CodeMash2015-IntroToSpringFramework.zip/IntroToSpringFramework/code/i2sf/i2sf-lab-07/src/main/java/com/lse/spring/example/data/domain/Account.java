package com.lse.spring.example.data.domain;

public interface Account {
	String getType();
	String getAccountNumber();
	Double getBalance();
	double credit(double amount);	
	double debit(double amount);
}
