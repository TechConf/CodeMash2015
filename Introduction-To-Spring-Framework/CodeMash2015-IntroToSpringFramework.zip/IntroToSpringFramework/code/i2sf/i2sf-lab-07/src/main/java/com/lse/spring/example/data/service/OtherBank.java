package com.lse.spring.example.data.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.lse.spring.example.data.domain.Account;
import com.lse.spring.example.data.persistence.AccountDAO;
import com.lse.spring.example.data.persistence.MissingAccountException;

/**
 * @author ddlucas
 */
@Service("theBank")
@Profile("other-bank")
public class OtherBank implements Bank {
	@Value("${other.bank.name}")
	private String bankName = "OtherBank";	

	@Value("${other.bank.balance}")
	private double checkingBalance;

	@Autowired
	private AccountDAO accountDao;
	
	public OtherBank() {
		System.out.println("creating OtherBank...");
	}

	public double creditAccount(String accountNumber, double amount) {
		Account account = fetchAccount(accountNumber);
		System.out.println("bank checking balance: "+account.getBalance()+" for accountNumber="+accountNumber);
		System.out.println("adding amount="+amount);
		account.credit(amount);
		account = accountDao.save(account);
		System.out.println("bank checking balance: "+account.getBalance()+" for accountNumber="+accountNumber);
		return account.getBalance();
	}

	public double debitAccount(String accountNumber, double amount) {
		Account account = fetchAccount(accountNumber);
		System.out.println("bank checking balance: "+account.getBalance()+" for accountNumber="+accountNumber);
		System.out.println("subtracting amount="+amount);
		account.debit(amount);
		account = accountDao.save(account);
		System.out.println("bank checking balance: "+account.getBalance()+" for accountNumber="+accountNumber);
		return account.getBalance();
	}

	private Account fetchAccount(String accountNumber) {
		System.out.println("looking up accountNumber="+accountNumber);
		Account account = accountDao.fetchAccount(accountNumber);
		if (account==null) {
			throw new MissingAccountException("account "+account+" not found");
		}
		return account;
	}
	
	public AccountDAO getAccountDao() {
		return accountDao;
	}

	public void setAccountDao(AccountDAO accountDao) {
		this.accountDao = accountDao;
	}

	public String getBankName() {
		return bankName;
	}
	
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public double getAccountBalance(String accountNumber) {
		Account account = fetchAccount(accountNumber);
		return account.getBalance();
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("{ class: ");
		sb.append(this.getClass().getCanonicalName());
		sb.append(",\n\t bankName: ").append(bankName);
		sb.append(",\n\t accountDao: ").append(accountDao);
		sb.append(" }\n");		
		return sb.toString();
	}

}
