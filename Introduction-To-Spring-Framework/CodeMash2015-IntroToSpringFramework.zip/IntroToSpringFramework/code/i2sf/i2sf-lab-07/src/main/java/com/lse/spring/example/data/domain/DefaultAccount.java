package com.lse.spring.example.data.domain;


import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


public class DefaultAccount implements Account {
	@NotNull
	private String type;
	
	@NotNull
	@Size(max=10,min=10)
	private String accountNumber;
		
	@Min(25)
	private Double balance;
	
	public DefaultAccount() {	
	}
	
	public DefaultAccount(String type, String accountNumber, double balance) {
		this.type = type;
		this.accountNumber = accountNumber;
		this.balance = balance;
	}
	
	public DefaultAccount(Account account) {
		this.type = account.getType();
		this.accountNumber = account.getAccountNumber();
		this.balance = account.getBalance();
	}

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccount(String account) {
		this.accountNumber = account;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	
	public double credit(double amount) {
		balance += amount;
		return balance;
	}
	
	public double debit(double amount) {
		balance -= amount;
		return balance;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("{ class: ");
		sb.append(this.getClass().getCanonicalName());
		sb.append(",\n\t type: ").append(type);
		sb.append(",\n\t accountNumber: ").append(accountNumber);
		sb.append(",\n\t balance: ").append(balance);
		sb.append(" }\n");		
		return sb.toString();
	}	
}
