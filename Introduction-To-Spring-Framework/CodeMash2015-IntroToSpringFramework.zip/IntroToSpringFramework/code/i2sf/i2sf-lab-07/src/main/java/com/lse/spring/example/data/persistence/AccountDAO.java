package com.lse.spring.example.data.persistence;

import java.util.List;

import com.lse.spring.example.data.domain.Account;

public interface AccountDAO {
	Account fetchAccount(String accountNumber);
	Account save(Account account);
	Account remove(String accountNumber);
	int countAllAccounts();
	List<Account> fetchAccountListByAcctType(String acctType);
}
