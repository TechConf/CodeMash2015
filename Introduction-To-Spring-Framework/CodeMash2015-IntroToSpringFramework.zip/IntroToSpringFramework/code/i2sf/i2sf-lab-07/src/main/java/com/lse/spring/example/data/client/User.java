package com.lse.spring.example.data.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.lse.spring.example.data.application.ATM;

/**
 * @author ddlucas
 */
@Component
public class User {
	@Autowired
	private ATM atm;

	@Value("${my.account.number}")
	private String accountNumber;

	public User() {
		System.out.println("creating User...");
		// atm = new AcmeATM();
	}

	public ATM getAtm() {
		return atm;
	}

	public void setAtm(ATM atm) {
		this.atm = atm;
	}

	public String getCheckingAccountNumber() {
		return accountNumber;
	}

	public void setCheckingAccountNumber(String checkingAccountNumber) {
		this.accountNumber = checkingAccountNumber;
	}

	public double getCheckingBalance() {
		return atm.getAccountBalance(accountNumber);
	}
	
	public double withdrawFromChecking(double amount) {
		return atm.withdrawFromAccount(accountNumber,amount);
	}
	
	public double depositToChecking(double amount) {
		return atm.depositToAccount(accountNumber,amount);
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("{ class: ");
		sb.append(this.getClass().getCanonicalName());
		sb.append(",\n\t atm: ").append(atm);
		sb.append(",\n\t accountNumber: ").append(accountNumber);
		sb.append(" }\n");		
		return sb.toString();
	}
}
